module.exports = () => {
  return [
    {
      id: 110,
      name: "Ahemdabad",
    },
    {
      id: 41,
      name: "Bangalore",
    },
    {
      id: 58,
      name: "Calcutta Central Branch (Test)",
    },
    {
      id: 29,
      name: "Chennai",
    },
    {
      id: 108,
      name: "Daman",
    },
    {
      id: 4,
      name: "Delhi",
    },
    {
      id: 46,
      name: "Delhi NCR",
    },
    {
      id: 104,
      name: "Faridabad",
    },
    {
      id: 106,
      name: "Goa",
    },
    {
      id: 109,
      name: "Gujrat",
    },
    {
      id: 107,
      name: "Himachal pradesh",
    },
    {
      id: 116,
      name: "HO",
    },
    {
      id: 103,
      name: "Jaipur",
    },
    {
      id: 11,
      name: "Kolkata",
    },
    {
      id: 102,
      name: "Lucknow",
    },
    {
      id: 118,
      name: "Malaysia",
    },
    {
      id: 3,
      name: "Mumbai",
    },
    {
      id: 57,
      name: "nagpur",
    },
    {
      id: 12,
      name: "Nasik",
    },
    {
      id: 113,
      name: "Navi Mumbai",
    },
    {
      id: 117,
      name: "Philippines",
    },
    {
      id: 64,
      name: "Pondicherry- PUDU",
    },
    {
      id: 19,
      name: "Pune",
    },
    {
      id: 105,
      name: "Punjab",
    },
    {
      id: 112,
      name: "Vashi",
    },
    {
      id: 111,
      name: "Worli",
    },
  ];
};
