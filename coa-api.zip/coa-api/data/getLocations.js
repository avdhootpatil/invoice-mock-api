module.exports = () => {
  return [
    {
      id: 4,
      name: "Delhi",
    },
    {
      id: 3,
      name: "Mumbai",
    },
  ];
};
