module.exports = () => {
  return [
    {
      id: "31",
      name: "costGL1",
      group: "group1",
      type: "expence",
      code: "A123B23",
    },
    {
      id: "32",
      name: "costGL2",
      group: "group1",
      type: "expence",
      code: "A123B23",
    },
    {
      id: "c01",
      name: "costGL-1-list",
      group: "group1",
      type: "expence",
      code: "A123B23",
    },
    {
      id: "c02",
      name: "costGL-2-list",
      group: "group2",
      type: "expence",
      code: "A123C23",
    },
    {
      id: "c03",
      name: "costGL-3-list",
      group: "group3",
      type: "expence",
      code: "A123D23",
    },
    {
      id: "c04",
      name: "costGL-4-list",
      group: "group4",
      type: "expence",
      code: "A123E23",
    },
    {
      id: "c05",
      name: "costGL-1-list",
      group: "group1",
      type: "expence",
      code: "A123B23",
    },
    {
      id: "c06",
      name: "costGL-2-list",
      group: "group2",
      type: "expence",
      code: "A123C23",
    },
    {
      id: "c07",
      name: "costGL-3-list",
      group: "group3",
      type: "expence",
      code: "A123D23",
    },
    {
      id: "c08",
      name: "costGL-4-list",
      group: "group4",
      type: "expence",
      code: "A123E23",
    },
  ];
};
