module.exports = () => {
  return [
    {
      code: "GST",
      name: "GST",
    },
    {
      code: "VAT",
      name: "VAT",
    },
  ];
};
