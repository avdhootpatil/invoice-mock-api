module.exports = () => {
  return [
    {
      id: "1102",
      name:
        "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      cess: 20,
      taxGroup: "GST",
    },
    {
      id: "1204",
      name:
        "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1202",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1203",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1205",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1206",
      name:
        "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1207",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1208",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1209",
      name:
        "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1210",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1211",
      name: "67890-EFBHS",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
    {
      id: "1212",
      name:
        "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
      code: "05689",
      taxRate: {
        id: "21",
        name: "GST18",
      },
      taxGroup: "GST",
    },
  ];
};
