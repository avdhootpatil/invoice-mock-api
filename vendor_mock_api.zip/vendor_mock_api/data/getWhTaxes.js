module.exports = () => {
  return [
    {
      taxId: 1,
      name: "194 C",
      taxCode: "194 C",
      taxRate: 2,
    },
    {
      taxId: 2,
      name: "195 C",
      taxCode: "195 C",
      taxRate: 3,
    },
    {
      taxId: 3,
      name: "196 C",
      taxCode: "196 C",
      taxRate: 4,
    },
  ];
};
