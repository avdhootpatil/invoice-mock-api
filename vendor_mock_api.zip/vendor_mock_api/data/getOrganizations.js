module.exports = () => {
  return [
    {
      id: 2056,
      name: "Monitor Logistics",
      code: "",
    },
    {
      id: 15005,
      name: "Jatin info pvt ltd",
      code: "",
    },
    {
      id: 17472,
      name: "TestOrgNov2019",
      code: "TON2019",
    },
    {
      id: 17475,
      name: "Test02Dec",
      code: "",
    },
    {
      id: 1885,
      name: "Maruti Logistics",
      code: "",
    },
    {
      id: 17474,
      name: "Test29Nov2019",
      code: "TESt29N",
    },
    {
      id: 6,
      name: "1STSERVE LOGISTICS INC",
      code: "1STSERVE",
    },
    {
      id: 1687,
      name: "Amar Pvt Ltd.",
      code: "",
    },
    {
      id: 1721,
      name: "myVendor",
      code: "mv",
    },
    {
      id: 1882,
      name: "I Logistics",
      code: "",
    },
    {
      id: 17473,
      name: "Test29Nov2019",
      code: "TESt29N",
    },
    {
      id: 5,
      name: "1618 OFFICE SOLUTIONS INC.",
      code: "1618",
    },
    {
      id: 33,
      name: "ABOITIZ TRANSPORT SYSTEMS CORP",
      code: "ATSC1201",
    },
    {
      id: 1611,
      name: "Navjyot International Trading Pvt. Limited",
      code: "NITP",
    },
    {
      id: 1612,
      name: "Atish Industries Ltd.",
      code: "AIL",
    },
    {
      id: 1613,
      name: "Nisarga Biotech Pvt. Ltd",
      code: "NBPL",
    },
    {
      id: 1625,
      name: "New Directions Marketing Ltd",
      code: "NDML",
    },
    {
      id: 1628,
      name: "Indian Sugar Corporation Limited",
      code: "ISCL",
    },
    {
      id: 1638,
      name: "Air India",
      code: "Ai",
    },
    {
      id: 1657,
      name: "Andrew Telecom India Pvt. Ltd.",
      code: "",
    },
    {
      id: 1658,
      name: "Andrew Corporation Arm-A",
      code: "",
    },
    {
      id: 1661,
      name: "LEWIS DESIGNS PVT. LTD.",
      code: "",
    },
    {
      id: 1666,
      name: "American Airlines.",
      code: "",
    },
    {
      id: 1680,
      name: "Dell Info",
      code: "DL",
    },
    {
      id: 1688,
      name: "Flora Corporations",
      code: "FLC",
    },
    {
      id: 1689,
      name: "Astra Shipping Line",
      code: "",
    },
    {
      id: 1690,
      name: "WALMART TRADING INC",
      code: "WT",
    },
    {
      id: 1709,
      name: "LAKHAMSIGH BHUTRA CO",
      code: "LBC",
    },
    {
      id: 1718,
      name: "Dog Sweets & Farsan",
      code: "SUBODH",
    },
    {
      id: 1719,
      name: "Reabok India Pvt Ltd",
      code: "",
    },
    {
      id: 1728,
      name: "Oriental Health Care",
      code: "OHC",
    },
    {
      id: 1732,
      name: "SANDHU TRANSPORTER",
      code: "STC",
    },
    {
      id: 1735,
      name: "WI infotech",
      code: "",
    },
    {
      id: 1736,
      name: "SWAN INTERNAL LTD",
      code: "",
    },
    {
      id: 1739,
      name: "pharma pvt ltd",
      code: "",
    },
    {
      id: 1742,
      name: "Logitech Pvt Ltd",
      code: "",
    },
    {
      id: 1743,
      name: "HINDUSTAN POLYMERS",
      code: "HP",
    },
    {
      id: 1744,
      name: "GGL SINGAPORE PTE",
      code: "",
    },
    {
      id: 1748,
      name: "Lourance Pvt Ltd",
      code: "",
    },
    {
      id: 1749,
      name: "LOGITECH INDIA PVT LTD",
      code: "",
    },
    {
      id: 1754,
      name: "HTC ltd",
      code: "",
    },
    {
      id: 1756,
      name: "honda private ltd",
      code: "",
    },
    {
      id: 1757,
      name: "smokin jones ltd",
      code: "",
    },
    {
      id: 1758,
      name: "cargo's pvt ltd",
      code: "",
    },
    {
      id: 1761,
      name: "tupperware company",
      code: "",
    },
    {
      id: 1762,
      name: "Air Canada Ltd",
      code: "ACL",
    },
    {
      id: 1763,
      name: "Star Traders",
      code: "ST",
    },
    {
      id: 1766,
      name: "Nexus technologies",
      code: "NEXT",
    },
    {
      id: 1768,
      name: "B P G india logistics",
      code: "",
    },
    {
      id: 1777,
      name: "Micro Logistics",
      code: "",
    },
    {
      id: 1790,
      name: "Air Canada",
      code: "AC",
    },
    {
      id: 1791,
      name: "ANTRIX CORPORATION",
      code: "ANT",
    },
    {
      id: 1792,
      name: "HAFEEZ SAYEED SUGAR MILLS.",
      code: "LeT",
    },
    {
      id: 1819,
      name: "Demo organization for testing",
      code: "testing",
    },
    {
      id: 1844,
      name: "Kharche Associates",
      code: "",
    },
    {
      id: 1845,
      name: "FZ Express",
      code: "",
    },
    {
      id: 1846,
      name: "MyTest Cust",
      code: "",
    },
    {
      id: 1850,
      name: "CEAT INDIA LTD",
      code: "",
    },
    {
      id: 1883,
      name: "AMRITSAR   SERVICES  Logistics  INDIA  PRIVATE LTD",
      code: "",
    },
    {
      id: 1886,
      name: "Emirates",
      code: "",
    },
    {
      id: 1887,
      name: "Delta Air Lines",
      code: "DEL",
    },
    {
      id: 1888,
      name: "Kuwait Airways",
      code: "KU",
    },
    {
      id: 1889,
      name: "Caribbean Airlines",
      code: "CA",
    },
    {
      id: 1892,
      name: "Air Berlin",
      code: "",
    },
    {
      id: 1897,
      name: "Clearship Forwarders Pvt Ltd",
      code: "CFPL",
    },
    {
      id: 1918,
      name: "Softlink Global1",
      code: "",
    },
    {
      id: 1927,
      name: "Mobile Logistics pvt Ltd",
      code: "ML",
    },
    {
      id: 1930,
      name: "Skyline Food Management .Inc",
      code: "SFM",
    },
    {
      id: 1935,
      name: "Test Logistics",
      code: "",
    },
    {
      id: 1937,
      name: "Clock Logistics",
      code: "",
    },
    {
      id: 1939,
      name: "Evolive Logistics",
      code: "",
    },
    {
      id: 1940,
      name: "SVL Logistics pvt Ltd",
      code: "",
    },
    {
      id: 1941,
      name: "XYZ logistics pvt ltd",
      code: "",
    },
    {
      id: 1944,
      name: "P & L International",
      code: "",
    },
    {
      id: 1952,
      name: "PQR Logistics",
      code: "",
    },
    {
      id: 1955,
      name: "UASC",
      code: "uasc",
    },
    {
      id: 1957,
      name: "Notation Logistics Ltd.",
      code: "NLL",
    },
    {
      id: 1962,
      name: "FROMMER INTERNATIONAL",
      code: "RG4",
    },
    {
      id: 1963,
      name: "Indiana Oils & Perfumes",
      code: "",
    },
    {
      id: 1970,
      name: "TEST ORG",
      code: "TO",
    },
    {
      id: 1977,
      name: "United Logistics Pvt. Ltd.",
      code: "",
    },
    {
      id: 1981,
      name: "ABC $#",
      code: "",
    },
    {
      id: 1985,
      name: "Air Mauritius",
      code: "",
    },
    {
      id: 1987,
      name: "GANESH POLYCHEM LTD",
      code: "",
    },
    {
      id: 1989,
      name: "XYZ Logistics",
      code: "",
    },
    {
      id: 1994,
      name: "ABILITIES INDIA PISTONS & RINGS PRIVATE TRASN LTD",
      code: "",
    },
    {
      id: 1996,
      name: "MUKHERJEE TRANSPORT INDUSTIES",
      code: "",
    },
    {
      id: 1997,
      name: "Vishal Enterprises",
      code: "",
    },
    {
      id: 1998,
      name: "HABA-SPED AG",
      code: "HGD",
    },
    {
      id: 2002,
      name: "Diamond Export Pvt. Ltd.",
      code: "DEPL",
    },
    {
      id: 2007,
      name: "DTDC Exports",
      code: "DTD",
    },
    {
      id: 2021,
      name: "Brand Marketing Inc.",
      code: "",
    },
    {
      id: 2022,
      name: "Brand Marketing India",
      code: "",
    },
    {
      id: 2041,
      name: "DOCTOR INDIA LTD - E2e",
      code: "",
    },
    {
      id: 2043,
      name: "Shreyank Global Private Limited",
      code: "",
    },
    {
      id: 2049,
      name: "APT LOGISTICS",
      code: "",
    },
    {
      id: 2051,
      name: "Zindal Corp",
      code: "ZC",
    },
    {
      id: 2057,
      name: "Gem Stone logistics pvt ltd.",
      code: "",
    },
    {
      id: 2072,
      name: "KUV Logisticts Pvt ltd.",
      code: "KUV ",
    },
    {
      id: 2073,
      name: "Logistics Germany",
      code: "",
    },
    {
      id: 2091,
      name: "ACL Coporation",
      code: "ACP",
    },
    {
      id: 2167,
      name: "Seal logistics pvt.ltd",
      code: "Seal ",
    },
    {
      id: 2172,
      name: "Melon Logistics",
      code: "",
    },
    {
      id: 2175,
      name: "ABC Crago Limited",
      code: "ACLL",
    },
    {
      id: 2183,
      name: "Larsen & Turbo",
      code: "L & T ",
    },
    {
      id: 2184,
      name: "Impex Limited",
      code: "",
    },
    {
      id: 2192,
      name: "AMIT logistics Pvt ltd",
      code: "",
    },
    {
      id: 2197,
      name: "shal",
      code: "",
    },
    {
      id: 2198,
      name: "HINDUSTAN HDFC",
      code: "",
    },
    {
      id: 2204,
      name: "SIEMENS LTD",
      code: "SUI",
    },
    {
      id: 2211,
      name: "Abbott S.A.",
      code: "",
    },
    {
      id: 2212,
      name: "OPEX TECHNOLOGY PVT. LTD.",
      code: "",
    },
    {
      id: 2215,
      name: "Suraj Logistics",
      code: "",
    },
    {
      id: 10155,
      name: "Best Breeds Inc.",
      code: "",
    },
    {
      id: 10156,
      name: "DAIKIN INDIA PVT LTD",
      code: "",
    },
    {
      id: 10157,
      name: "SK Shine Ltd",
      code: "",
    },
    {
      id: 10159,
      name: "DL Rise pvt ltd",
      code: "",
    },
    {
      id: 10165,
      name: "Zespri India Ltd.",
      code: "",
    },
    {
      id: 10166,
      name: "Zespri International",
      code: "",
    },
    {
      id: 10168,
      name: "Chenab Impex Pvt Ltd",
      code: "",
    },
    {
      id: 10169,
      name: "Choco Berries",
      code: "",
    },
    {
      id: 10170,
      name: "La Roche Chocolate",
      code: "",
    },
    {
      id: 10171,
      name: "VARDHAMAN FANCY STORE",
      code: "",
    },
    {
      id: 10172,
      name: "Anedya Foods Private Limited",
      code: "",
    },
    {
      id: 10173,
      name: "Durham-Ellis Pecan Co",
      code: "",
    },
    {
      id: 10174,
      name: "HP India Ltd",
      code: "",
    },
    {
      id: 10177,
      name: "ABB Indian Ltd.",
      code: "",
    },
    {
      id: 10182,
      name: "Sony pvt ltd",
      code: "",
    },
    {
      id: 10184,
      name: "KLP pvt ltd",
      code: "",
    },
    {
      id: 10185,
      name: "Sanghvi Associates",
      code: "SA",
    },
    {
      id: 10188,
      name: "HABASPED SWITZERLAND",
      code: "HSZ",
    },
    {
      id: 10189,
      name: "TRP global ltd",
      code: "",
    },
    {
      id: 10191,
      name: "Fabtech",
      code: "",
    },
    {
      id: 10197,
      name: "PROVOGUE TRANSPORT PVT LTD",
      code: "",
    },
    {
      id: 10199,
      name: "CADILA PHARMACEUTICALS LTD.",
      code: "",
    },
    {
      id: 10474,
      name: "C J SHAH & CO",
      code: "",
    },
    {
      id: 10475,
      name: "Mahadev Enterprises",
      code: "",
    },
    {
      id: 10477,
      name: "MATRIX INDIA PVT LTD",
      code: "",
    },
    {
      id: 10483,
      name: "Adventure Cargo Pvt. Ltd.",
      code: "",
    },
    {
      id: 11131,
      name: "Softlink China Global Pvt Ltd.",
      code: "",
    },
    {
      id: 11134,
      name: "Softlink Hong kong Global Pvt Ltd.",
      code: "SHKG",
    },
    {
      id: 11156,
      name: "CHINA FREIGHT FORWARDINGS CO., LTD",
      code: "",
    },
    {
      id: 11211,
      name: "Global logistics pvt ltd",
      code: "",
    },
    {
      id: 11212,
      name: "Local logistics pvt ltd",
      code: "",
    },
    {
      id: 14474,
      name: "Yako Moto Intl",
      code: "YMI",
    },
    {
      id: 14483,
      name: "Phoenix logistics pvt ltd",
      code: "",
    },
    {
      id: 14484,
      name: "lllklkl",
      code: "",
    },
    {
      id: 14493,
      name: "Yamaha Motors",
      code: "YM",
    },
    {
      id: 14523,
      name: "Priceline Ltd",
      code: "PCL",
    },
    {
      id: 14524,
      name: "H R Traders",
      code: "HR",
    },
    {
      id: 14526,
      name: "Deafult company",
      code: "DC",
    },
    {
      id: 14530,
      name: "Foreign logistics pvt ltd",
      code: "",
    },
    {
      id: 14532,
      name: "zenfo pvt ltd",
      code: "",
    },
    {
      id: 14542,
      name: "RR logistics solutions ltd",
      code: "",
    },
    {
      id: 14544,
      name: "HP Speed india pvt ltd",
      code: "",
    },
    {
      id: 14546,
      name: "Aamar solutions ltd",
      code: "",
    },
    {
      id: 14998,
      name: "Local logistics solutions pvt ltd",
      code: "",
    },
    {
      id: 15004,
      name: "Starhorse Shipping",
      code: "SHS",
    },
    {
      id: 15010,
      name: "Navjivan Pvt. Ltd.",
      code: "",
    },
    {
      id: 15011,
      name: "New Org",
      code: "NO",
    },
    {
      id: 15015,
      name: "Ukinex Logistics",
      code: "",
    },
    {
      id: 15016,
      name: "Test Logistics 1",
      code: "",
    },
    {
      id: 15023,
      name: "Air Srilanka",
      code: "",
    },
    {
      id: 15024,
      name: "Divine Logistics Private Limited",
      code: "",
    },
    {
      id: 15048,
      name: "Air Tanzania",
      code: "",
    },
    {
      id: 15055,
      name: "Triway Inc.",
      code: "TWI",
    },
    {
      id: 15062,
      name: "XYZ Logisywerwer",
      code: "",
    },
    {
      id: 15063,
      name: "P&P ltd",
      code: "",
    },
    {
      id: 15068,
      name: "Dhirajglobalpvtltd",
      code: "dgp",
    },
    {
      id: 15074,
      name: "Shipper Cartage Coordinator",
      code: "",
    },
    {
      id: 15075,
      name: "Shipper A/C Manager",
      code: "",
    },
    {
      id: 15076,
      name: "Consignee customer Services",
      code: "",
    },
    {
      id: 15077,
      name: "Consignee A/C Branch Manager",
      code: "",
    },
    {
      id: 15083,
      name: "Transporter Branch",
      code: "TB",
    },
    {
      id: 15091,
      name: "IKEA INDIA PRIVATE Limited",
      code: "IKEA",
    },
    {
      id: 15092,
      name: "IKEA DISTR. DC2 PIACENZA",
      code: "",
    },
    {
      id: 15103,
      name: "Shipper One Pvt ltd",
      code: "Shipper One",
    },
    {
      id: 15128,
      name: "Test",
      code: "",
    },
    {
      id: 15129,
      name: "Test2",
      code: "",
    },
    {
      id: 15130,
      name: "Test3",
      code: "",
    },
    {
      id: 15131,
      name: "Test345",
      code: "ABCD",
    },
    {
      id: 15132,
      name: "Test1234",
      code: "",
    },
    {
      id: 15133,
      name: "Test6",
      code: "",
    },
    {
      id: 15135,
      name: "Testing",
      code: "",
    },
    {
      id: 15691,
      name: "IKEA DISTR. DC1 PIACENZA",
      code: "",
    },
    {
      id: 15692,
      name: "APL",
      code: "",
    },
    {
      id: 15711,
      name: "Sattva Hi-Tech and Conware Pvt Ltd",
      code: "",
    },
    {
      id: 15713,
      name: "Maersk Line (India) Pvt Ltd",
      code: "",
    },
    {
      id: 15714,
      name: "Sattva Conware Pvt Ltd",
      code: "",
    },
    {
      id: 15715,
      name: "Broadway Logistics Pvt Ltd",
      code: " ",
    },
    {
      id: 15716,
      name: "Creative logistics pvt ltd",
      code: " ",
    },
    {
      id: 15717,
      name: "Bombay Logistics",
      code: " ",
    },
    {
      id: 15718,
      name: "Calcutta Logistics",
      code: " ",
    },
    {
      id: 15719,
      name: "Organization2710",
      code: "Org",
    },
    {
      id: 15726,
      name: "Innovative Logistics Pvt Ltd",
      code: "ILPL",
    },
    {
      id: 15727,
      name: "GVL INDIA PVT LTD",
      code: "",
    },
    {
      id: 15730,
      name: "CARGO CARE LOGISTIC",
      code: "",
    },
    {
      id: 15732,
      name: "ViewSonic Pvt. Ltd.",
      code: "VSPL",
    },
    {
      id: 17085,
      name: "abc",
      code: "",
    },
    {
      id: 17088,
      name: "EDI ABC Pvt Ltd",
      code: "",
    },
    {
      id: 17476,
      name: "Test Org Pvt Ltd",
      code: "TOPL",
    },
    {
      id: 17481,
      name: "vita Logistics",
      code: "VTS",
    },
    {
      id: 3,
      name: "11 FTC ENT INC",
      code: "11FE12011",
    },
    {
      id: 1614,
      name: "Sumanta India Transport Pvt. Ltd.",
      code: "SITPL",
    },
    {
      id: 1615,
      name: "Amruta Metal Industries",
      code: "AMI",
    },
    {
      id: 1616,
      name: "EverQuick Freight Forwarders Pvt. Ltd",
      code: "EQFF",
    },
    {
      id: 1617,
      name: "International Freight Forwarders Inc",
      code: "IFFI",
    },
    {
      id: 1618,
      name: "M/s Pure DIets India Pvt Ltd.",
      code: "PDIP",
    },
    {
      id: 1619,
      name: "BioTech Healthcare Ltd",
      code: "BTH",
    },
    {
      id: 1620,
      name: "Maersk Line Limited",
      code: "MLL",
    },
    {
      id: 1623,
      name: "Global Trading Group Ltd",
      code: "GTGL",
    },
    {
      id: 1624,
      name: "Browder Synergy Freights Ltd",
      code: "BSFL",
    },
    {
      id: 1626,
      name: "Zhejiang Yingerjian Sportgoods  Ltd.",
      code: "ZYSL",
    },
    {
      id: 1629,
      name: "Aryan International Ltd",
      code: "AILM",
    },
    {
      id: 1630,
      name: "Accura Organic Foods Forwarders Ltd",
      code: "AOFFL",
    },
    {
      id: 1631,
      name: "British Airways Inc",
      code: "BAI",
    },
    {
      id: 1637,
      name: "Raghav Export's India Ltd",
      code: "REIL",
    },
    {
      id: 1642,
      name: "A M I India Logistics",
      code: "AMIIL-1640",
    },
    {
      id: 1654,
      name: "Denis Info Pvt Ltd.",
      code: "DIPL",
    },
    {
      id: 1669,
      name: "UTC International",
      code: "",
    },
    {
      id: 1677,
      name: "Dawood",
      code: " ",
    },
    {
      id: 1681,
      name: "D. D. Associates",
      code: "DDA",
    },
    {
      id: 1685,
      name: "Panasonic ltd",
      code: "pld",
    },
    {
      id: 1695,
      name: "Clover Tech pvt .ltd",
      code: "CR",
    },
    {
      id: 1697,
      name: "Great Freight Forwarder",
      code: "GFF",
    },
    {
      id: 1710,
      name: "Sai Suvarna",
      code: "SS",
    },
    {
      id: 1711,
      name: "ABC India Pvt LTD,",
      code: "AIPL",
    },
    {
      id: 1720,
      name: "Divine Nature Pvt. Ltd.",
      code: "DNPL",
    },
    {
      id: 1726,
      name: "Software Techno Pvt Ltd",
      code: "STPL",
    },
    {
      id: 1727,
      name: "ATN CORPORATION",
      code: "ACC",
    },
    {
      id: 1730,
      name: "Neptune Forwarders & Suppliers Pvt.Limited Company",
      code: "NEP",
    },
    {
      id: 1731,
      name: "MALHOTRA & COMPANY",
      code: "",
    },
    {
      id: 1738,
      name: "Aavinash International",
      code: "AVA",
    },
    {
      id: 1740,
      name: "Belkin bag",
      code: "bg",
    },
    {
      id: 1746,
      name: "Indo Arab Exporters",
      code: "IAE",
    },
    {
      id: 1747,
      name: "East india Exports",
      code: "EIE",
    },
    {
      id: 1759,
      name: "baggit pvt ltd",
      code: "",
    },
    {
      id: 1760,
      name: "esbeda organization",
      code: "",
    },
    {
      id: 1765,
      name: "Maruti Pvt Ltd.",
      code: "",
    },
    {
      id: 1769,
      name: "Samsung Logistics pvt ltd",
      code: "",
    },
    {
      id: 1775,
      name: "Pen Logistics",
      code: "",
    },
    {
      id: 1786,
      name: "New Organizationssssss",
      code: "",
    },
    {
      id: 1898,
      name: "Triway Forwarders Private Limited",
      code: "TFPL",
    },
    {
      id: 1901,
      name: "Coca-cola Logistics",
      code: "",
    },
    {
      id: 1925,
      name: "BIOCON INTERNATION (GLOBAL)",
      code: "BIG",
    },
    {
      id: 1928,
      name: "Govinda logistics pvt.ltd",
      code: "GLPL",
    },
    {
      id: 1929,
      name: "WireLess Logistics",
      code: "",
    },
    {
      id: 1931,
      name: "BOROSIL GLASS WORKS LTD",
      code: "",
    },
    {
      id: 1932,
      name: "BOROSIL AFRASIA FZE",
      code: "",
    },
    {
      id: 1936,
      name: "NYK LINES LTD",
      code: "",
    },
    {
      id: 1938,
      name: "Cell Logistics",
      code: "",
    },
    {
      id: 1948,
      name: "Dhiraj Export Pvt Ltd",
      code: "DEP",
    },
    {
      id: 1950,
      name: "All India Logistics pvt. Ltd.",
      code: "",
    },
    {
      id: 1951,
      name: "MUKHERJEE TRANSPORT",
      code: "",
    },
    {
      id: 1954,
      name: "HCL Logistics pvt ltd",
      code: "HCL",
    },
    {
      id: 1967,
      name: "Ramesh Tr",
      code: "",
    },
    {
      id: 1968,
      name: "Ramzan transporter",
      code: "",
    },
    {
      id: 1974,
      name: "Harold Pvt Ltd",
      code: "",
    },
    {
      id: 1982,
      name: "Kale Logistics",
      code: "",
    },
    {
      id: 1988,
      name: "New Global Freight Forwarders Pvt. Ltd.",
      code: "NGFF",
    },
    {
      id: 1993,
      name: "VASANT GLOBAL PRIVATE LIMITED",
      code: "",
    },
    {
      id: 1995,
      name: "Shipco Transport Inc.",
      code: "",
    },
    {
      id: 1999,
      name: "A. J. WOOD",
      code: "",
    },
    {
      id: 2000,
      name: "Air - India",
      code: "",
    },
    {
      id: 2012,
      name: "Bottel Logistics pvt ltd",
      code: "",
    },
    {
      id: 2018,
      name: "DHL Express pvt.ltd.",
      code: "DHL",
    },
    {
      id: 2024,
      name: "EVER OK AIR",
      code: "",
    },
    {
      id: 2027,
      name: "Overshine logistics pvt ltd",
      code: "",
    },
    {
      id: 2042,
      name: "A2Z Logistics",
      code: "",
    },
    {
      id: 2045,
      name: "America Gloabl Logistics CR S.A",
      code: "",
    },
    {
      id: 2052,
      name: "GBS Logistics pvt ltd",
      code: "",
    },
    {
      id: 2053,
      name: "Dow Fashion Pvt. Ltd.",
      code: "DFP",
    },
    {
      id: 2054,
      name: "Astra Logistics Pvt Ltd.",
      code: "",
    },
    {
      id: 2055,
      name: "Astrashine logistics pvt ltd",
      code: "",
    },
    {
      id: 2064,
      name: "ISOVOLTA SAU",
      code: "ISOSAUBCN ",
    },
    {
      id: 2066,
      name: "Flyhigh logistics pvt ltd",
      code: "",
    },
    {
      id: 2067,
      name: "Softlink Global Ltd - US",
      code: "",
    },
    {
      id: 2068,
      name: "Loginext Inc",
      code: "",
    },
    {
      id: 2070,
      name: "United UTC Inc-Chicago",
      code: "",
    },
    {
      id: 2071,
      name: "Software Testing pvt ltd",
      code: "",
    },
    {
      id: 2077,
      name: "Astra logistics pvt ltd",
      code: "",
    },
    {
      id: 2079,
      name: "Flybig logistics pvt ltd",
      code: "",
    },
    {
      id: 2174,
      name: "Abroad logistics pvt ltd",
      code: "",
    },
    {
      id: 2177,
      name: "Softlink GLobal INC",
      code: "",
    },
    {
      id: 2178,
      name: "E2E Logistics Pvt. Ltd.",
      code: "",
    },
    {
      id: 2179,
      name: "Rohit shipping services",
      code: "",
    },
    {
      id: 2193,
      name: "SPSP Logistics",
      code: "SP",
    },
    {
      id: 2200,
      name: "TVS Pvt Ltd.",
      code: "",
    },
    {
      id: 2205,
      name: "Volkswagen Group Sales India Private Limited",
      code: "",
    },
    {
      id: 2206,
      name: "Zinner Pvt Ltd",
      code: "",
    },
    {
      id: 2207,
      name: "ZINNER CHINA",
      code: "",
    },
    {
      id: 10175,
      name: "GLOBAL TRADING SERVICES INDIA",
      code: "",
    },
    {
      id: 10176,
      name: "Hogard logistics pvt ltd",
      code: "",
    },
    {
      id: 10178,
      name: "Astraglow logistics pvt ltd",
      code: "",
    },
    {
      id: 10179,
      name: "Parkson Filters",
      code: "PFT",
    },
    {
      id: 10190,
      name: "Direx",
      code: "",
    },
    {
      id: 10194,
      name: "l & t",
      code: "",
    },
    {
      id: 10198,
      name: "Western Union",
      code: "WU",
    },
    {
      id: 11129,
      name: "ABC Shanghai Pvt Ltd.",
      code: "",
    },
    {
      id: 11138,
      name: "Enhance",
      code: "Enh",
    },
    {
      id: 14473,
      name: "ABC INTERNATIONAL",
      code: "ABCINT",
    },
    {
      id: 14488,
      name: "Avon Cycle Ltd",
      code: "",
    },
    {
      id: 14489,
      name: "JINDAL AUTOMOBILE PVT. LTD.",
      code: "JINDAL SAW",
    },
    {
      id: 14490,
      name: "LOME LABORATORIES",
      code: "LOME LAB",
    },
    {
      id: 14491,
      name: "Zee info ltd",
      code: "",
    },
    {
      id: 14494,
      name: "KARA LOGISTICS",
      code: "KARA",
    },
    {
      id: 14496,
      name: "Herald logistics pvt ltd",
      code: "",
    },
    {
      id: 14512,
      name: "Affiliate Org",
      code: "AFORG",
    },
    {
      id: 14522,
      name: "Domestic logistics pvt ltd.",
      code: "",
    },
    {
      id: 14525,
      name: "United Shipping",
      code: "USP",
    },
    {
      id: 14529,
      name: "S A Enterprises",
      code: "SAE",
    },
    {
      id: 14535,
      name: "BPL tech pvt ltd",
      code: "",
    },
    {
      id: 14540,
      name: "KKL logistics solutions ltd",
      code: "",
    },
    {
      id: 14541,
      name: "KPL log pvt ltd",
      code: "",
    },
    {
      id: 14545,
      name: "Aaryan tech pvt ltd",
      code: "",
    },
    {
      id: 14548,
      name: "Logistics solutions pvt ltd",
      code: "",
    },
    {
      id: 15001,
      name: "QWERTY LOGISTICS",
      code: "",
    },
    {
      id: 15003,
      name: "Lenovo Computers Pvt. Ltd.",
      code: "LCPL",
    },
    {
      id: 15007,
      name: "Geeta Shipping",
      code: "",
    },
    {
      id: 15013,
      name: "HBC india pvt ltd",
      code: "",
    },
    {
      id: 15026,
      name: "Six Sigma Logistics Pvt Ltd",
      code: "SSLPL",
    },
    {
      id: 15029,
      name: "Xenith Enterprises",
      code: "XE",
    },
    {
      id: 15030,
      name: "Relax Airline",
      code: "",
    },
    {
      id: 15049,
      name: "Gurunath Logistics Pvt Ltd",
      code: "",
    },
    {
      id: 15056,
      name: "Softlink India Pvt. LTD",
      code: "",
    },
    {
      id: 15057,
      name: "AAKAS HEALTH CARE",
      code: "MUM",
    },
    {
      id: 15067,
      name: "AkshayglobalPVTLTD",
      code: "agp",
    },
    {
      id: 15078,
      name: "Origin Agent Branch",
      code: "",
    },
    {
      id: 15079,
      name: "Destination Agent Branch",
      code: "",
    },
    {
      id: 15082,
      name: "Booking thru Branch",
      code: "",
    },
    {
      id: 15087,
      name: "Global Agent",
      code: "GAgnt",
    },
    {
      id: 15122,
      name: "Singh Associates",
      code: "ASAS",
    },
    {
      id: 15123,
      name: "Lookup media Pvt. Ltd.",
      code: "LMPL",
    },
    {
      id: 15125,
      name: "Fedex Global services Pvt Ltd.",
      code: "",
    },
    {
      id: 15126,
      name: "Aryan tech ltd",
      code: "",
    },
    {
      id: 15136,
      name: "Air cargo pvt ltd",
      code: "",
    },
    {
      id: 15693,
      name: "MARK INTERNATIONAL INC",
      code: "",
    },
    {
      id: 15696,
      name: "Govinda Transport Center",
      code: "GTC",
    },
    {
      id: 15697,
      name: "Govinda Transport Center(UDF)",
      code: "GTC(UDF)",
    },
    {
      id: 15703,
      name: "RohitC Overseas",
      code: "",
    },
    {
      id: 15704,
      name: "Maestro ltd",
      code: "",
    },
    {
      id: 15705,
      name: "DHL ltd",
      code: "",
    },
    {
      id: 15725,
      name: "Malaysia International",
      code: "MI",
    },
    {
      id: 15733,
      name: "Vivo Phone Pvt LTD",
      code: "VPPL",
    },
    {
      id: 17086,
      name: "A-1 HOSPITALITY SERVICES",
      code: "",
    },
    {
      id: 17087,
      name: "GLOBAL PROJEKT LOGISTIQUE PVT. LTD.",
      code: "",
    },
    {
      id: 17477,
      name: "TOrgCreditLTD",
      code: "TOCL",
    },
    {
      id: 17478,
      name: "SoftWeb pvt ltd",
      code: "SWP",
    },
    {
      id: 17479,
      name: "WildCraft Org",
      code: "WCo",
    },
  ];
};
