module.exports = () => {
  return [
    {
      id: 1,
      number: "A123G",
      orgName: "sketch ko",
    },
    {
      id: 2,
      number: "A678",
      orgName: "encircle",
    },
    {
      id: 3,
      number: "A986",
      orgName: "plank",
    },
  ];
};
