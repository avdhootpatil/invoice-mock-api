module.exports = () => {
  return [
    {
      name: "Cash",
      id: 1,
      type: "Income",
    },
    {
      name: "Cheque",
      id: 2,
      type: "Expense",
    },
    {
      name: "Bank Transfer",
      id: 3,
      type: "Income",
    },
    {
      name: "OnlineTransfer",
      id: 4,
      type: "Expense",
    },
    {
      name: "Others",
      id: 5,
      type: "Income",
    },
  ];
};
