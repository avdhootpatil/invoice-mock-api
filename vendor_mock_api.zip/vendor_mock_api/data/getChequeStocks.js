module.exports = () => {
  return [
    {
      id: 73,
      chequeNo: "050150",
      status: 1,
      trnId: 3662,
      source: "T",
      isDraft: false,
      remarks: "",
      modifiedOn: null,
      usedLocId: 0,
    },
    {
      id: 73,
      chequeNo: "050151",
      status: 1,
      trnId: 3518,
      source: "V",
      isDraft: false,
      remarks: "",
      modifiedOn: null,
      usedLocId: 0,
    },
  ];
};
