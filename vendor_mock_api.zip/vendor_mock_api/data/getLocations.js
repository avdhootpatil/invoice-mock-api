module.exports = () => {
  return [
    { id: 1, name: "Mumbai" },
    { id: 2, name: "Pune" },
    { id: 3, name: "Nagpur" },
    { id: 4, name: "Kolhapur" },
    { id: 5, name: "Nagr" },
    { id: 6, name: "Satara" },
  ];
};
