module.exports = () => {
  return [
    {
      id: "A",
      name:
        "A : Deduction Lorem ipsum is a placeholder text commonly used to demonstrate the",
    },
    {
      id: "B",
      name: "B : Transcation",
    },
    {
      id: "C",
      name:
        "C : Deduction Lorem ipsum is a placeholder text commonly used to demonstrate the",
    },
    {
      id: "D",
      name: "D : Deduction",
    },
  ];
};
